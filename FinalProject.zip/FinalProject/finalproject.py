import turtle

#Creates the letter 'X' for each move that the player makes
def letterX(t, length):

    half_length = length / 2
    hypotenuse = (2 * half_length**2)**0.5

    t.pendown()
    t.right(45)
    t.forward(half_length)
    t.left(135)

    t.penup()
    t.forward(hypotenuse)
    t.pendown()

    t.left(135)
    t.forward(length)
    t.right(135)

    t.penup()
    t.forward(hypotenuse)
    t.pendown()

    t.right(135)
    t.forward(half_length)
    t.left(45)
    t.penup()

# getting a Screen to work on
ws=turtle.Screen()

ws.setup(width=402, height=350)
 

#defines the board that will keep track of whose move goes where
theBoard = {'7': ' ' , '8': ' ' , '9': ' ' ,
            '4': ' ' , '5': ' ' , '6': ' ' ,
            '1': ' ' , '2': ' ' , '3': ' ' }

board_keys = []

for key in theBoard:
    board_keys.append(key)

def game():
    #Setting up the board using Turtle Graphics
    t=turtle.Turtle()

    t.color("Black")
 
    t.width("2")
 
    t.speed(2)

    t.penup()
    t.goto(-150,-42)
    t.pendown()
 
    t.forward(300)
 
    t.penup()
    t.goto(-150,57)
    t.pendown()
 
    t.forward(300)
 
    t.penup()
    t.goto(-50,-142)
    t.pendown()
 
    t.left(90)
    t.forward(300)
     
    t.penup()
    t.goto(50,-142)
    t.pendown()
 
    t.forward(300)
    t.hideturtle()

    #X gets to move first
    turn = 'X'
    count = 0

    while(count < 10):
        print("\nIt's your turn, " + turn + ". Where would you like to play?")
        print("1. Bottom Right")
        print("2. Bottom Middle")
        print("3. Bottom Left")
        print("4. Middle Right")
        print("5. Middle Middle")
        print("6. Middle Left")
        print("7. Top Right")
        print("8. Top Middle")
        print("9. Top Left")
        
        move = input("Please select where you would like to move: ")
        
        #Error correction if the user inputs a value out of the range or not an integer
        try:
            intMove = int(move)
            if(intMove > 9 or intMove < 1):
                print("\nThat value is not in range of 1-9")
                continue
        except ValueError:
            print("\nYou must enter an integer in an open space on the board between 1-9")
            continue
            
        #Creates the turtle images for where the player selects to move
        #and keeps track of the move for the player
        if theBoard[move] == ' ':
            theBoard[move] = turn
            if(move == '1'):
                if (turn == 'X'):
                    x = turtle.Turtle()
                    x.penup()
                    x.sety(-100)
                    x.setx(105)
                    letterX(x, 100)
                    x.hideturtle()
                else:
                    circles = turtle.Turtle()
                    circles.penup()
                    circles.sety(-135)
                    circles.setx(105)
                    r = 40
                    circles.pendown()
                    circles.circle(r)
                    circles.hideturtle()
            elif(move == '2'):
                if (turn == 'X'):
                    x = turtle.Turtle()
                    x.penup()
                    x.sety(-100)
                    letterX(x, 100)
                    x.hideturtle()
                else:
                    circles = turtle.Turtle()
                    circles.penup()
                    circles.sety(-135)
                    r = 40
                    circles.pendown()
                    circles.circle(r)
                    circles.hideturtle()
            elif(move == '3'):
                if (turn == 'X'):
                    x = turtle.Turtle()
                    x.penup()
                    x.sety(-100)
                    x.setx(-105)
                    letterX(x, 100)
                    x.hideturtle()
                else:
                    circles = turtle.Turtle()
                    circles.penup()
                    circles.sety(-135)
                    circles.setx(-105)
                    r = 40
                    circles.pendown()
                    circles.circle(r)
                    circles.hideturtle()
            elif(move == '4'):
                if (turn == 'X'):
                    x = turtle.Turtle()
                    x.penup()
                    x.setx(105)
                    letterX(x, 100)
                    x.hideturtle()
                else:
                    circles = turtle.Turtle()
                    circles.penup()
                    circles.setx(105)
                    circles.sety(-30)
                    r = 40
                    circles.pendown()
                    circles.circle(r)
                    circles.hideturtle()
            elif(move == '5'):
                if (turn == 'X'):
                    x = turtle.Turtle()
                    x.penup()
                    x.sety(12)
                    letterX(x, 100)
                    x.hideturtle()
                else:
                    circles = turtle.Turtle()
                    circles.penup()
                    circles.sety(-30)
                    r = 40
                    circles.pendown()
                    circles.circle(r)
                    circles.hideturtle()
            elif(move == '6'):
                if (turn == 'X'):
                    x = turtle.Turtle()
                    x.penup()
                    x.setx(-105)
                    letterX(x, 100)
                    x.hideturtle()
                else:
                    circles = turtle.Turtle()
                    circles.penup()
                    circles.setx(-105)
                    circles.sety(-30)
                    r = 40
                    circles.pendown()
                    circles.circle(r)
                    circles.hideturtle()
            elif(move == '7'):
                if (turn == 'X'):
                    x = turtle.Turtle()
                    x.penup()
                    x.sety(110)
                    x.setx(105)
                    letterX(x, 100)
                    x.hideturtle()
                else:
                    circles = turtle.Turtle()
                    circles.penup()
                    circles.sety(70)
                    circles.setx(105)
                    r = 40
                    circles.pendown()
                    circles.circle(r)
                    circles.hideturtle()
            elif(move == '8'):
                if (turn == 'X'):
                    x = turtle.Turtle()
                    x.penup()
                    x.sety(110)
                    letterX(x, 100)
                    x.hideturtle()
                else:
                    circles = turtle.Turtle()
                    circles.penup()
                    circles.sety(70)
                    r = 40
                    circles.pendown()
                    circles.circle(r)
                    circles.hideturtle()
            elif(move == '9'):
                if (turn == 'X'):
                    x = turtle.Turtle()
                    x.penup()
                    x.sety(110)
                    x.setx(-105)
                    letterX(x, 100)
                    x.hideturtle()
                else:
                    circles = turtle.Turtle()
                    circles.penup()
                    circles.sety(70)
                    circles.setx(-105)
                    r = 40
                    circles.pendown()
                    circles.circle(r)
                    circles.hideturtle()
            count += 1
        else:
            print("\nThat place is already filled. Please enter another integer from 1-9")
            continue
        
        if count >= 5:
            if theBoard['7'] == theBoard['8'] == theBoard['9'] != ' ': # across the top
                print("\nGame Over.\n")                
                print("**** Congratulations " + turn + " you've won! ****\n")                
                break
            elif theBoard['4'] == theBoard['5'] == theBoard['6'] != ' ': # across the middle
                print("\nGame Over.\n")                
                print("**** Congratulations " + turn + " you've won! ****\n")
                break
            elif theBoard['1'] == theBoard['2'] == theBoard['3'] != ' ': # across the bottom
                print("\nGame Over.\n")                
                print("**** Congratulations " + turn + " you've won! ****\n")
                break
            elif theBoard['1'] == theBoard['4'] == theBoard['7'] != ' ': # down the left side
                print("\nGame Over.\n")                
                print("**** Congratulations " + turn + " you've won! ****\n")
                break
            elif theBoard['2'] == theBoard['5'] == theBoard['8'] != ' ': # down the middle
                print("\nGame Over.\n")                
                print("**** Congratulations " + turn + " you've won! ****\n")
                break
            elif theBoard['3'] == theBoard['6'] == theBoard['9'] != ' ': # down the right side
                print("\nGame Over.\n")                
                print("**** Congratulations " + turn + " you've won! ****\n")
                break 
            elif theBoard['7'] == theBoard['5'] == theBoard['3'] != ' ': # diagonal
                print("\nGame Over.\n")                
                print("**** Congratulations " + turn + " you've won! ****\n")
                break
            elif theBoard['1'] == theBoard['5'] == theBoard['9'] != ' ': # diagonal
                print("\nGame Over.\n")                
                print("**** Congratulations " + turn + " you've won! ****\n")
                break 

        # If neither X nor O wins and the board is full, we'll declare the result as 'tie'.
        if count == 9:
            print("\nGame Over.\n")                
            print("It's a Tie!!\n")
            break

        # Change the player after every move.
        if turn =='X':
            turn = 'O'
        else:
            turn = 'X'        
    
    # Ask if player wants to restart the game or not.
    restart = input("Would you like to play again?(Yes/No) ")
    if restart == "Yes" or restart == "yes":
        ws.clearscreen()    #Clears the turtle graphics screen so that the new game can commence
        for key in board_keys:
            theBoard[key] = " "

        game()


print("Welcome to two player Tic-Tac-Toe using Turtle Graphics")
game() #Calls the game to start
turtle.bye() #Telling the graphics that it is done being used
