#Greg Ryterski
#gjr7dz, 18186949
#3/4/2021
import Animals
        
print("Welcome to the animal generator!")
print("This program creates Animal objects.")
doCalculation = True
animalList = []
while(doCalculation):
    animalType = input("\nWhat type of animal would you like to create? ")
    animalName = input("What is the animal's name? ")
    
    newAnimal = Animals.Animal(animalType, animalName)
    animalList.append(newAnimal)
    anotherCalculation = input("\nWould you like to add more animals (y/n)? ")
    if(anotherCalculation != "y"):
        break
    
print("\nAnimal List:")
for x in animalList:
    print(x.get_name, "the", x.get_animal_type, "is", x.check_mood)

