#Greg Ryterski
#gjr7dz, 18186949
#3/4/2021
import random

class Animal:
    def __init__(self, __animal_type, __name):
        self.__animal_type = __animal_type
        self.__name = __name
        
        randomMood = random.randint(1, 3)
        if(randomMood == 1):
            self.__mood = "happy"
        elif(randomMood == 2):
            self.__mood = "hungry"
        else:
            self.__mood = "sleepy"

    @property
    def get_animal_type(self):
        return self.__animal_type
    
    @property
    def get_name(self):
        return self.__name
    
    @property
    def check_mood(self):
        return self.__mood
        

