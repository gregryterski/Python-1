#Greg Ryterski
#gjr7dz, 18186949
#2/18/2021

print("Number Stats.\n")
do_calculation = True
while(do_calculation):
    fileName = input("Enter the File name: ")
    try:
        f = open(fileName, "r")
        content = f.read()
        coList = content.split("\n")
        count = 0
        totalSum = 0
        averageNum = 0

        for i in range(len(coList)):
            try:
                compareNum = int(coList[i])
                if(i == 0):
                    minNum = compareNum
                    maxNum = compareNum
            
                if(compareNum < minNum):
                    minNum = compareNum
                if(compareNum > maxNum):
                    maxNum = compareNum
                
                totalSum += compareNum
                count += 1
            except ValueError:
                break
        

        averageNum = totalSum/count
        rangeNum = maxNum - minNum
            
        print("Sum: " + str(totalSum))
        print("Count: " + str(count))
        print("Average: " + str(averageNum))
        print("Maximum: " + str(maxNum))
        print("Minimum: " + str(minNum))
        print("Range: " + str(rangeNum))

        f.close()
        
    except FileNotFoundError:
            print("There is no file with the name: " + fileName)

    another_calculation = input("Would you like to evaluate another file? (y/n): ")
    if(another_calculation != "y"):
            do_calculation = False
    else:
        print("\n\nNew Number Stats.\n")
