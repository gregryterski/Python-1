# Greg Ryterski
# gjr7dz, 18186949
# 4/6/2021

def encodeTxt(letter):
    if(letter == 'a'):
        return '0'
    elif(letter == 'b'):
        return '1'
    elif(letter == 'c'):
        return '2'
    elif(letter == 'd'):
        return '3'
    elif(letter == 'e'):
        return '4'
    elif(letter == 'f'):
        return '5'
    elif(letter == 'g'):
        return '6'
    elif(letter == 'h'):
        return '7'
    elif(letter == 'i'):
        return '8'
    elif(letter == 'j'):
        return '9'
    elif(letter == 'k'):
        return '!'
    elif(letter == 'l'):
        return '@'
    elif(letter == 'm'):
        return '#'
    elif(letter == 'n'):
        return '$'
    elif(letter == 'o'):
        return '%'
    elif(letter == 'p'):
        return '^'
    elif(letter == 'q'):
        return '&'
    elif(letter == 'r'):
        return '*'
    elif(letter == 's'):
        return '('
    elif(letter == 't'):
        return ')'
    elif(letter == 'u'):
        return '-'
    elif(letter == 'v'):
        return '+'
    elif(letter == 'w'):
        return '<'
    elif(letter == 'x'):
        return '>'
    elif(letter == 'y'):
        return '?'
    elif(letter == 'z'):
        return '='
    else:
        return letter

def decodeTxt(letter):
    if(letter == '0'):
        return 'a'
    elif(letter == '1'):
        return 'b'
    elif(letter == '2'):
        return 'c'
    elif(letter == '3'):
        return 'd'
    elif(letter == '4'):
        return 'e'
    elif(letter == '5'):
        return 'f'
    elif(letter == '6'):
        return 'g'
    elif(letter == '7'):
        return 'h'
    elif(letter == '8'):
        return 'i'
    elif(letter == '9'):
        return 'j'
    elif(letter == '!'):
        return 'k'
    elif(letter == '@'):
        return 'l'
    elif(letter == '#'):
        return 'm'
    elif(letter == '$'):
        return 'n'
    elif(letter == '%'):
        return 'o'
    elif(letter == '^'):
        return 'p'
    elif(letter == '&'):
        return 'q'
    elif(letter == '*'):
        return 'r'
    elif(letter == '('):
        return 's'
    elif(letter == ')'):
        return 't'
    elif(letter == '-'):
        return 'u'
    elif(letter == '+'):
        return 'v'
    elif(letter == '<'):
        return 'w'
    elif(letter == '>'):
        return 'x'
    elif(letter == '?'):
        return 'y'
    elif(letter == '='):
        return 'z'
    else:
        return letter

doCalculation = True

while(doCalculation):
    try:
        print("\nWelcome to the Secret Message Encoder/Decoder")
        print("1. Encode a message")
        print("2. Decode a message")
        print("3. Exit\n")
        encDecExt = int(input("What would you like to do? "))
        if(encDecExt > 3 or encDecExt < 1):
            print("\nYou can only enter integer values of 1-3. Please try again!")
            continue
        if(encDecExt == 1):
            encString = input("\nEnter a message to encode: ")
            encodedString = ''
            for letter in encString:
                try:
                    encodedString += encodeTxt(letter)
                except TypeError:
                    encodedString += ' '
            print("Encoded Message:", encodedString)
        elif(encDecExt == 2):
            decString = input("\nEnter a message to decode: ")
            decodedString = ''
            for letter in decString:
                try:
                    decodedString += decodeTxt(letter)
                except TypeError:
                    decodedString += ' '
            print("Decoded Message:", decodedString)
        elif(encDecExt == 3):
            doCalculation = False
    except ValueError:
        print("\nYou can only enter integer values of 1-3. Please try again!")
