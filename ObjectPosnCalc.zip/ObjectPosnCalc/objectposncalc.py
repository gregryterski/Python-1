x0 = input("Enter the inital position(in meters): ") #Prompts the user to enter the inital position
positionResult = x0.replace('.', '', 1)
while(not positionResult.isdigit()):    #This is created for error check to make sure the user entered a number
    print("Error not a number")
    x0 = input("Enter the inital position(in meters): ")
    positionResult = x0.replace('.', '', 1)

v0 = input("Enter the inital velocity(in meters/second): ")
velocityResult = v0.replace('.', '', 1)
while(not velocityResult.isdigit()):
    print("Error not a number")
    v0 = input("Enter the inital velocity(in meters/second): ")
    velocityResult = v0.replace('.', '', 1)
    
acceleration = input("Enter the acceleration(meters/second^2): ")
accResult = acceleration.replace('.', '', 1)
while(not accResult.isdigit()):
    print("Error not a number")
    acceleration = input("Enter the acceleration(meters/second^2): ")
    accResult = acceleration.replace('.', '', 1)
    
time = input("Enter the time(in seconds): ")
timeResult = time.replace('.', '', 1)
while(not timeResult.isdigit()):
    print("Error not a number")
    time = input("Enter the time(in seconds): ")
    timeResult = time.replace('.', '', 1)

x0 = float(x0) #Assigns the values to be of the class float instead of string
v0 = float(v0)
acceleration = float(acceleration)
time = float(time)

xf = x0 + v0 * time + 0.5 * acceleration * time * time #Formula is xf = x0 + v0t + ½at^2

print("The final position of the object is " + str(xf)) #Prints the final location of the object
