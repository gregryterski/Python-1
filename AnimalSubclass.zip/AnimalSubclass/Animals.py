#Greg Ryterski
#gjr7dz, 18186949
#3/25/2021
import random

class Animal:
    def __init__(self, __animal_type, __name):
        self.__animal_type = __animal_type
        self.__name = __name
        
        randomMood = random.randint(1, 3)
        if(randomMood == 1):
            self.__mood = "happy"
        elif(randomMood == 2):
            self.__mood = "hungry"
        else:
            self.__mood = "sleepy"

    @property
    def get_animal_type(self):
        return self.__animal_type
    
    @property
    def get_name(self):
        return self.__name
    
    @property
    def check_mood(self):
        return self.__mood

class Mammal(Animal):
    def __init__(self, __animal_type, __name, __hair_color):
        super().__init__(__animal_type, __name)
        self.__hair_color = __hair_color
    def get_hair_color(self):
        return __hair_color

class Bird(Animal):
    def __init__(self, __animal_type, __name, __can_fly):
        super().__init__(__animal_type, __name)
        self.__can_fly = __can_fly
    def get_can_fly(self):
        return __can_fly
