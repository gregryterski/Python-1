#Greg Ryterski
#gjr7dz, 18186949
#3/25/2021
import Animals
        
print("Welcome to the animal generator!")
print("This program creates Animal objects.")
doCalculation = True
animalList = []
while(doCalculation):
    try:
        print("\nWould you like to create a mammal or bird?")
        print("1. Mammal")
        print("2. Bird")
        mamOrBird = int(input("Which would you like to create? "))
    except:
        print("Please enter 1 for mammal or 2 for bird")
        continue
    
    if(mamOrBird == 1):
        mammalType = input("\nWhat type of mammal would you like to create? ")
        mammalName = input("What is the mammal's name? ")
        mammalHair = input("What color is the mammal's hair? ")
        newMammal = Animals.Mammal(mammalType, mammalName, mammalHair)
        animalList.append(newMammal)
    elif(mamOrBird == 2):
        birdType = input("\nWhat type of bird would you like to create? ")
        birdName = input("What is the bird's name? ")
        birdFly = input("Can the bird fly? ")
        newBird = Animals.Bird(birdType, birdName, birdFly)
        animalList.append(newBird)
    else:
        print("Please enter 1 for mammal or 2 for bird")
        continue
    
    anotherCalculation = input("\nWould you like to add more animals (y/n)? ")
    if(anotherCalculation != "y"):
        break
    
print("\nAnimal List:")
for x in animalList:
    print(x.get_name, "the", x.get_animal_type, "is", x.check_mood)

