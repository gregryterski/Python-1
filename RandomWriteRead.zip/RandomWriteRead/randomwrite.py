# Greg Ryterski
# gjr7dz, 18186949
# 2/17/2021
import random

print("Random Number File Writer.\n")

f = open("randomnum.txt", "w")

while(True):
    try:
        numRandomNums = int(input("How many random numbers do you want? "))
        if(numRandomNums < 0):
            print("Inputted number should be a positive integer")
            continue
    except ValueError:
            print("The value you entered is invlaid. Only positive numerical integer values are accepted.")
    else:
            break

while(True):
    try:
        randomLowerBound = int(input("What should be the lowest random number: "))
        if(randomLowerBound < 0):
            print("Inputted number should be a positive integer")
            continue
    except ValueError:
            print("The value you entered is invlaid. Only positive numerical integer values are accepted.")
    else:
            break
        
while(True):
    try:
        randomUpperBound = int(input("What should be the highest random number: "))
        if(randomUpperBound < 0):
            print("Inputted number should be a positive integer")
            continue
        if(randomUpperBound < randomLowerBound):
            print("Upper bound must be higher than lower bound. Please try a different positive integer.")
            continue
    except ValueError:
            print("The value you entered is invlaid. Only positive numerical integer values are accepted.")
    else:
            break

for i in range(numRandomNums):
    randNum = random.randint(randomLowerBound, randomUpperBound)
    f.write(str(randNum) + "\n") #Content Written

print("The random numbers were written to randomnum.txt\n")
f.close()


