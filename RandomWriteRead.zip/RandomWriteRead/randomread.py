# Greg Ryterski
# gjr7dz, 18186949
# 2/17/2021

print("Random Number File Reader.\n")

try:
    f = open("randomnum.txt", "r")
    content = f.read()
    coList = content.split("\n")
    count = 0

    print("List of random numbers in randomnum.txt:")
    for i in coList:
        if i:
            count += 1

    print(content)
    print("Random number count: " + str(count))
except FileNotFoundError:
        print("There is no file with the name 'randomnum.txt'.")


