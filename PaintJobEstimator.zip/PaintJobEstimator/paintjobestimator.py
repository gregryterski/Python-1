# Greg Ryterski
# gjr7dz, 18186949
# 02/09/2021

import math

do_calculation = True
print("Paint Job Estimator.\n")

while(do_calculation):
    wallSpace = 350
    paintGallon = 1
    labor = 6
    laborPricePerHour = 62.25

    while(True):
        try:
            wallSpacePainted = float(input("Enter the square feet of wall space to be painted: "))
            if(wallSpacePainted < 0):
                print("Value must be greater than 0.")
                continue
        except ValueError:
                print("The Value you entered is invalid. Only positive numerical values are accepted.")
        else:
                break

    while(True):
        try:
            paintPricePerGallon = float(input("Enter the price of paint per gallon: "))
            if(paintPricePerGallon < 0):
                print("Value must be greater than 0.")
                continue
        except ValueError:
                print("The Value you entered is invalid. Only positive numerical values are accepted.")
        else:
                break

    paintGallon = math.ceil(wallSpacePainted/wallSpace)
    hoursOfLabor = (wallSpacePainted/wallSpace) * labor
    priceOfPaint = paintPricePerGallon * paintGallon
    laborCharges = laborPricePerHour * hoursOfLabor
    totalPrice = laborCharges + priceOfPaint

    print("The number of gallons of paint required: " + str(round(paintGallon, 0)))
    print("The hours of labor required: " + str(round(hoursOfLabor, 1)) + " hours")
    print("The cost of paint: $" + "{:.2f}".format(priceOfPaint, 2)) #formats the statement to always be 2 decmial places
    print("The cost of labor: $" + "{:.2f}".format(laborCharges, 2))
    print("The total cost of the paint job: $" + "{:.2f}".format(totalPrice, 2))

    another_calculation = input("Would you like to do another estimate? (y/n): ") #lets the user estimate another paint job if 'y' is typed
    if(another_calculation != "y"):
        do_calculation = False
    else:
        print("\n\nNew Paint Job Estimator.\n")
