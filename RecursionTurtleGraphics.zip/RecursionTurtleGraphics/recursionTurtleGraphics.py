# Greg Ryterski
# gjr7dz, 18186949
# 3/25/2021

import random
from turtle import Turtle

def recursive_graphics(turtle, angle, length, delta):
    colors = ["salmon", "firebrick", "orangered", "darkred"]
    turtle.color(random.choice(colors))
    if (length < 124):
        turtle.right(angle)
        turtle.forward(length)
        length = length + delta
        angle = angle - 10
        recursive_graphics(turtle, angle, length, delta)
    elif (length == 124):
        ANIMATION_SPEED = 0
        circleboi = Turtle()
        circleboi.speed(ANIMATION_SPEED)
        recursive_circles(circleboi, 45, 4, 2, 100)

        
def recursive_graphics2(turtle, angle, length, delta):
    colors = ["seagreen", "forestgreen", "darkgreen", "springgreen"]
    turtle.color(random.choice(colors))
    turtle.right(angle)
    turtle.forward(length)
    length = length + delta
    angle = angle - 10
    if(length < 125):
        recursive_graphics2(turtle, angle, length, delta)
    else:
        ANIMATION_SPEED = 0
        circleboi = Turtle()
        circleboi.speed(ANIMATION_SPEED)
        recursive_circles2(circleboi, 45, 12, 2, 25)

def recursive_graphics3(turtle, angle, length, delta):
    colors = ["orchid", "deeppink", "hotpink", "violet"]
    turtle.color(random.choice(colors))
    turtle.right(angle)
    turtle.forward(length)
    length = length + delta
    angle = angle - 10
    if(length < 125):
        recursive_graphics3(turtle, angle, length, delta)
        
def recursive_circles(turtle, angle, quantity, delta, radius):
    colors = ["saddlebrown", "sienna", "peru", "chocolate"]
    color = random.choice(colors)
    turtle.color(color)
    turtle.right(angle)
    turtle.forward(delta)
    unit_angle = 360.0/quantity
    for x in range(quantity):
        turtle.circle(radius)
        turtle.left(unit_angle)
    radius = radius - delta
    if (radius > 75):
        recursive_circles(turtle, angle, quantity, delta, radius)
    else:
        ANIMATION_SPEED = 0
        lineboi = Turtle()
        lineboi.speed(ANIMATION_SPEED)
        recursive_graphics2(lineboi, 91, 50, 1)

def recursive_circles2(turtle, angle, quantity, delta, radius):
    colors = ["turquoise", "lightseagreen", "salmon", "cyan"]
    color = random.choice(colors)
    turtle.color(color)
    turtle.right(angle)
    turtle.forward(delta)
    unit_angle = 360.0/quantity
    for x in range(quantity):
        turtle.circle(radius)
        turtle.left(unit_angle)
    radius = radius - delta
    if (radius > 5):
        recursive_circles2(turtle, angle, quantity, delta, radius)
    else:
        ANIMATION_SPEED = 0
        lineboi = Turtle()
        lineboi.speed(ANIMATION_SPEED)
        recursive_graphics3(lineboi, 171, 50, 1)
        
def main():
    random.seed()
    ANIMATION_SPEED = 0
    lineboi = Turtle()
    lineboi.speed(ANIMATION_SPEED)
    recursive_graphics(lineboi, 271, 1, 1)

main()
