#Greg Ryterski
#gjr7dz
#2/1/2021

print("This program calculates an object's final position.\n")
do_calculation = True
while(do_calculation):
    while(True):
        try:
            initial_position = float(input("Enter the object's inital position (in meters): "))
        except ValueError:
                print("The value you entered is invalid. Only numerical values are valid.")
        else:
                break

    while(True):
        try:   
            initial_velocity = float(input("Enter the object's initial velocity (in meters/second): "))
        except ValueError:
                print("The value you entered is invalid. Only numerical values are valid.")
        else:
                break

    while(True):
        try:
            acceleration = float(input("Enter the object's acceleration (in meters/second^2): "))
        except ValueError:
                print("The value you entered is invalid. Only numerical values are valid.")
        else:
                break

    while(True):
        try:
            time = float(input("Enter the time that has elapsed (in seconds): "))
            if(time < 0 ):
                print("Negative time is not allowed.")
                continue
        except ValueError:
                print("The value you entered is invalid. Only positive numerical values are valid.")
        else:
                break

    final_position = initial_position + initial_velocity * time + 0.5 * acceleration * time **2
    print("\nThe final position of the object is " + str(final_position))
    
    another_calculation = input("Do you want to perform another calculation? (y/n): ")
    if(another_calculation != "y"):
            do_calculation = False
    else:
        print("\n\nNew object position calculation.\n")
        
