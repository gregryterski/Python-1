#Greg Ryterski
#gjr7dz, 18186949
#2/18/2021

print("Number Stats 2.\n")
do_calculation = True
while(do_calculation):
    fileName = input("Enter the File name: ")
    try:
        f = open(fileName, "r")
        stringList = [(line.strip()).strip() for line in f]
        integer_change = map(int, stringList)
        coList = list(integer_change)
        coList.sort()
        totalSum = 0
        numbers = 0
        number_counts = {}
        modeLst = []
        maxCount = 0
        
        for i in range(len(coList)):
            try:
                compareNum = coList[i]
                
                try:
                    if(compareNum < minNum):
                        minNum = compareNum
                    if(compareNum > maxNum):
                        maxNum = compareNum

                except NameError:
                    minNum = compareNum
                    maxNum = compareNum
                
                totalSum += compareNum
                numbers += 1
                    
            except ValueError:
                continue
        
        averageNum = totalSum/numbers
        rangeNum = maxNum - minNum

        if numbers % 2 == 0:
            median1 = coList[numbers//2]
            median2 = coList[numbers//2 - 1]
            median = (median1 + median2)/2
        elif numbers == 1:
            median = coList[0]
        else:
            median = coList[numbers//2]

        for number in coList:
            if number in number_counts:
                number_counts[number] += 1
            if number not in number_counts:
                number_counts[number] = 1
                
        for number in number_counts:
            count = number_counts[number]
            
            if(count > maxCount):
                maxCount = count
    
        for number in number_counts:
            if number_counts[number] == maxCount:
                modeLst.append(number)

        print("Filename:", fileName)   
        print("Sum:", totalSum)
        print("Count:", numbers)
        print("Average:", averageNum)
        print("Maximum:", maxNum)
        print("Minimum:", minNum)
        print("Range:", rangeNum)
        print("Median:", median)
        print("Mode:", modeLst)
        f.close()
        del fileName
        del totalSum
        del numbers
        del averageNum
        del maxNum
        del minNum
        del rangeNum
        del median
        del modeLst
        del maxCount
        
    except FileNotFoundError:
            print("There is no file with the name:", fileName)
    except ZeroDivisionError:
            print("There are no numbers in", fileName)

    another_calculation = input("Would you like to evaluate another file? (y/n): ")
    if(another_calculation != "y"):
            do_calculation = False
    else:
        print("\n\nNew Number Stats 2.\n")
